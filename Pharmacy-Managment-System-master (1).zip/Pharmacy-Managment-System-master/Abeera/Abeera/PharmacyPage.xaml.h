#pragma once

#include "PharmacyPage.g.h"

namespace winrt::Abeera::implementation
{
    struct PharmacyPage : PharmacyPageT<PharmacyPage>
    {
        PharmacyPage()
        {
            InitializeComponent();
            LoadMedicines();


            // Xaml objects should not call InitializeComponent during construction.
            // See https://github.com/microsoft/cppwinrt/tree/master/nuget#initializecomponent
        }

        int32_t MyProperty();
        void MyProperty(int32_t value);

        void LoadMedicines();

        void LoadMedicinesIntoListView();

        void AddToBillButton_Click(winrt::Windows::Foundation::IInspectable const&, winrt::Microsoft::UI::Xaml::RoutedEventArgs const&);

      

        void BuyButton_Click(winrt::Windows::Foundation::IInspectable const&, winrt::Microsoft::UI::Xaml::RoutedEventArgs const&);


 

        //void myButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
    };
}

namespace winrt::Abeera::factory_implementation
{
    struct PharmacyPage : PharmacyPageT<PharmacyPage, implementation::PharmacyPage>
    {
    };
}
