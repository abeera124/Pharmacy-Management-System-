#include "pch.h"
#include "MainPage.xaml.h"
#include "MainPage.g.cpp"
#if __has_include("MainPage.g.cpp")
#endif
#include"Authentication.xaml.h"
#include <winrt/Windows.UI.Xaml.Interop.h>

using namespace winrt;
using namespace Microsoft::UI::Xaml;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace winrt::Abeera::implementation
{
    int32_t MainPage::MyProperty()
    {
        throw hresult_not_implemented();
    }

    void MainPage::MyProperty(int32_t /* value */)
    {
        throw hresult_not_implemented();
    }

    void MainPage::AdminButton_Click(IInspectable const&, RoutedEventArgs const&)
    {

        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::Authentication>());
        //AdminButton().Content(box_value(L"Admin"));
    }
    void MainPage::PharmacyButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        PharmacyButton().Content(box_value(L"Pharmacy"));
    }
    //PharmacyButton
}
