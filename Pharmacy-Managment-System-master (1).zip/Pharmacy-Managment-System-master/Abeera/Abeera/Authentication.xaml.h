#pragma once

#include "Authentication.g.h"

namespace winrt::Abeera::implementation
{
    struct Authentication : AuthenticationT<Authentication>
    {
        Authentication()
        {
            // Xaml objects should not call InitializeComponent during construction.
            // See https://github.com/microsoft/cppwinrt/tree/master/nuget#initializecomponent
        }

        int32_t MyProperty();
        void MyProperty(int32_t value);

        void submitButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
    };
}

namespace winrt::Abeera::factory_implementation
{
    struct Authentication : AuthenticationT<Authentication, implementation::Authentication>
    {
    };
}
