#include "pch.h"
#include "Authentication.xaml.h"
#if __has_include("Authentication.g.cpp")
#include "Authentication.g.cpp"
#endif
#include <winrt/Windows.UI.Xaml.Interop.h>
#include "MainPage.xaml.h"
using namespace winrt;
using namespace Microsoft::UI::Xaml;
//#include "MainPage.xaml.h"
#include "AdminPage.xaml.h"

#include "winrt/Microsoft.UI.Xaml.Controls.h"
#include "winrt/Microsoft.UI.Xaml.h"

#include "winrt/Microsoft.UI.Xaml.Navigation.h"


using namespace winrt;
using namespace Microsoft::UI::Xaml;
using namespace Microsoft::UI::Xaml::Controls;
// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace winrt::Abeera::implementation
{
    int32_t Authentication::MyProperty()
    {
        throw hresult_not_implemented();    
    }

    void Authentication::MyProperty(int32_t /* value */)
    {
        throw hresult_not_implemented();
    }

    void Authentication::submitButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        // Get the TextBox element by its name
        auto outputTextBlockElement = this->FindName(L"OutputTextBlock");
        auto usernameBox = this->FindName(L"UsernameTextBox").as<winrt::Microsoft::UI::Xaml::Controls::TextBox>();
        auto passwordBox = this->FindName(L"PasswordBox").as<winrt::Microsoft::UI::Xaml::Controls::TextBox>();
        

        auto outputTextBlock = outputTextBlockElement.as<winrt::Microsoft::UI::Xaml::Controls::TextBlock>();
        winrt::hstring username = usernameBox.Text();
        winrt::hstring password = passwordBox.Text();

        if (username == L"admin" && password == L"admin123")
        {
            auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
            this->Content(frame);
            frame.Navigate(winrt::xaml_typename<Abeera::AdminPage>());
            //myButton().Content(box_value(L"Clicked"));
        }
        else {
            outputTextBlock.Text(L"Invalid Usename or Password");  // Display the username in the TextBlock
        }

        // Set the OutputTextBlock's Text to show the username
        


    }

     /*   myButton().Content(box_value(L"Clicked"));*/
    
}
