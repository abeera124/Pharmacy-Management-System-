#include "pch.h"
#include "AddPage.xaml.h"
#include "AddPage.g.cpp"
#if __has_include("AddPage.g.cpp")
//#include "EditPage.xaml.h"
#endif
#include <winrt/Windows.UI.Xaml.Interop.h>
//#include "ViewSellRecord.xaml.h"
#include "EditPage.xaml.h"
#include "DeletePage.xaml.h"
#include "MainPage.xaml.h"
#include  "ViewMedicine.xaml.h"
#include "ViewSellRecord.xaml.h"


#include <fstream>
#include <sstream>

#include <windows.h> // For GetModuleFileNameW
#include <shlobj.h>  // For SHGetFolderPathW

//using namespace Windows::Storage;
using namespace winrt;
using namespace Microsoft::UI::Xaml;
using namespace Microsoft::UI::Xaml::Controls;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace winrt::Abeera::implementation
{
    int32_t AddPage::MyProperty()
    {
        throw hresult_not_implemented();
    }

    void AddPage::MyProperty(int32_t /* value */)
    {
        throw hresult_not_implemented();
    }

    /*void AddPage::myButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        myButton().Content(box_value(L"Clicked"));
    }*/
    
    void AddPage::EditButton_Click(IInspectable const&, RoutedEventArgs const&)
      {
          //myButton().Content(box_value(L"Clicked"));
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::EditPage>());
      }

    void AddPage::DeleteButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::DeletePage>());
    }

    void AddPage::ViewAllMedicineButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::ViewMedicine>());
    }

    void AddPage::ViewSellsRecordButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::ViewSellRecord>());
    }

    void AddPage::BackButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::MainPage>());
    }

    // Function to get writable file path in the app directory
    std::wstring GetAppDirectoryFilePath() {
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(NULL, path, MAX_PATH);

        std::wstring appPath = path;
        size_t pos = appPath.find_last_of(L"\\/");
        return appPath.substr(0, pos) + L"\\medicines.txt";
    }

    // Button click event handler
    void AddPage::AddButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        // Get input values
        std::wstring name = MedicineName().Text().c_str();
        std::wstring quantityStr = Quantity().Text().c_str();
        std::wstring priceStr = Price().Text().c_str();

        // Validate input
        int quantity = 0;
        double price = 0.0;
        try {
            quantity = std::stoi(quantityStr);
            price = std::stod(priceStr);
        }
        catch (...) {
            OutputTextBlock().Text(L"Invalid input! Please enter valid numbers.");
            return;
        }

        // Get writable file path
        std::wstring filePath = GetAppDirectoryFilePath();

        // Open file in append mode (does not overwrite)
        std::wofstream file(filePath, std::ios::app);
        if (!file) {
            OutputTextBlock().Text(L"Error: Could not open file.");
            return;
        }

        // Write new medicine entry to file
        file << name << L" " << quantity << L" " << price << std::endl;
        file.close();

        // Clear input fields
        MedicineName().Text(L"");
        Quantity().Text(L"");
        Price().Text(L"");

        // Show success message
        OutputTextBlock().Text(L"Medicine added successfully!");
    }
    
    
}
