#include "pch.h"
#include "DeletePage.xaml.h"
#if __has_include("DeletePage.g.cpp")
#include "DeletePage.g.cpp"
#endif



#include "AddPage.xaml.h"
#include "EditPage.xaml.h"
#include "ViewMedicine.xaml.h"
#include "MainPage.xaml.h"
#include "ViewSellRecord.xaml.h"

#include <fstream>
#include <sstream>

#include <windows.h> // For GetModuleFileNameW
#include <shlobj.h>  // For SHGetFolderPathW
#include <winrt/Windows.UI.Xaml.Interop.h>




using namespace winrt;
using namespace Microsoft::UI::Xaml;

using namespace Microsoft::UI::Xaml::Controls;

//using namespace winrt;
//using namespace Microsoft::UI::Xaml;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace winrt::Abeera::implementation
{
    int32_t DeletePage::MyProperty()
    {
        throw hresult_not_implemented();
    }

    void DeletePage::MyProperty(int32_t /* value */)
    {
        throw hresult_not_implemented();
    }

    void DeletePage::AddButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::AddPage>());
    }

    void DeletePage::EditButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::EditPage>());
    }

    void DeletePage::ViewAllMedicineButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::ViewMedicine>());
    }

    void DeletePage::ViewSellsRecordButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::ViewSellRecord>());
    }

    void DeletePage::BackButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::MainPage>());
    }



    // Function to get writable file path in the app directory
    static std::wstring GetAppDirectoryFilePath() {
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(NULL, path, MAX_PATH);

        std::wstring appPath = path;
        size_t pos = appPath.find_last_of(L"\\/");
        return appPath.substr(0, pos) + L"\\medicines.txt";
    }


    void DeletePage::DeleteButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        // Get the medicine name from the TextBox
        std::wstring nameToDelete = MedicineName().Text().c_str();
        if (nameToDelete.empty()) {
            OutputTextBlock().Text(L"Please enter a medicine name to delete.");
            return;
        }

        // Get the correct file path
        std::wstring filePath = GetAppDirectoryFilePath();

        // Load existing medicines
        std::vector<std::wstring> medicines;
        std::wifstream file(filePath);
        if (!file) {
            OutputTextBlock().Text(L"Error: Could not open file. Check if it exists.");
            return;
        }

        std::wstring line;
        bool found = false;
        while (std::getline(file, line)) {
            std::wstringstream ss(line);
            std::wstring medName;
            int quantity;
            double price;

            ss >> medName >> quantity >> price;

            if (medName != nameToDelete) {
                medicines.push_back(line); // Keep all except the deleted one
            }
            else {
                found = true;
            }
        }
        file.close();

        // If medicine was found, save the updated list
        if (found) {
            std::wofstream outFile(filePath, std::ios::trunc); // Overwrite file
            if (!outFile) {
                OutputTextBlock().Text(L"Error: Could not write to file.");
                return;
            }

            for (const auto& med : medicines) {
                outFile << med << std::endl;
            }
            outFile.close();

            OutputTextBlock().Text(L"Medicine deleted successfully. File path: "  );
        }
        else {
            OutputTextBlock().Text(L"Medicine not found.");
        }

        // Clear input field
        MedicineName().Text(L"");
    }
}
