#include "pch.h"
#include "ViewSellRecord.xaml.h"
#include "ViewSellRecord.g.cpp"
#if __has_include("ViewSellRecord.g.cpp")
#endif

using namespace winrt;
using namespace Microsoft::UI::Xaml;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace winrt::Abeera::implementation
{
    int32_t ViewSellRecord::MyProperty()
    {
        throw hresult_not_implemented();
    }

    void ViewSellRecord::MyProperty(int32_t /* value */)
    {
        throw hresult_not_implemented();
    }

   /* void ViewSellRecord::myButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        myButton().Content(box_value(L"Clicked"));
    }*/
}
