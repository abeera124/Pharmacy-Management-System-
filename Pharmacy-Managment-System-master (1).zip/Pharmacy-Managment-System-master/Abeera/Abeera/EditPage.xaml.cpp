#include "pch.h"
#include "EditPage.xaml.h"
#include "EditPage.g.cpp"
#if __has_include("EditPage.g.cpp")
#endif
#include <winrt/Windows.UI.Xaml.Interop.h>
#include "AddPage.xaml.h"
#include"DeletePage.xaml.h"
#include "ViewMedicine.xaml.h"
#include "MainPage.xaml.h"
#include "ViewSellRecord.xaml.h"

#include <fstream>
#include <sstream>

#include <windows.h> // For GetModuleFileNameW
#include <shlobj.h>  // For SHGetFolderPathW




using namespace winrt;
using namespace Microsoft::UI::Xaml;

using namespace Microsoft::UI::Xaml::Controls;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace winrt::Abeera::implementation
{
    int32_t EditPage::MyProperty()
    {
        throw hresult_not_implemented();
    }

    void EditPage::MyProperty(int32_t /* value */)
    {
        throw hresult_not_implemented();
    }

    void EditPage::AddButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::AddPage>());
    }

    void EditPage::DeleteButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::DeletePage>());
    }

    void EditPage::ViewAllButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::ViewMedicine>());
    }

    void EditPage::ViewSellsButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::ViewSellRecord>());
    }

    void EditPage::BackButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::MainPage>());
    }


    // Function to get writable file path in the app directory
    static std::wstring GetAppDirectoryFilePath() {
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(NULL, path, MAX_PATH);

        std::wstring appPath = path;
        size_t pos = appPath.find_last_of(L"\\/");
        return appPath.substr(0, pos) + L"\\medicines.txt";
    }

    void EditPage::UpdateButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        // Get input values
        std::wstring name = MedicineName().Text().c_str();
        std::wstring quantityStr = Quantity().Text().c_str();
        std::wstring priceStr = Price().Text().c_str();

        if (name.empty()) {
            OutputTextBlock().Text(L"Please enter a medicine name.");
            return;
        }

        // Convert input values
        int newQuantity = -1;
        int newPrice = -1;

        try {
            if (!quantityStr.empty()) newQuantity = std::stoi(quantityStr);
            if (!priceStr.empty()) newPrice = std::stod(priceStr);
        }
        catch (...) {
            OutputTextBlock().Text(L"Invalid quantity or price format.");
            return;
        }

        // Get writable file path
        std::wstring filePath = GetAppDirectoryFilePath();

        // Read file content
        std::wifstream file(filePath);
        if (!file) {
            OutputTextBlock().Text(L"Error: Could not open file.");
            return;
        }

        std::vector<std::wstring> lines;
        std::wstring line;
        bool found = false;

        while (std::getline(file, line)) {
            std::wstringstream ss(line);
            std::wstring medName;
            int quantity;
            int price;

            ss >> medName >> quantity >> price;

            if (medName == name) {
                found = true;
                if (newQuantity != -1) quantity = newQuantity;
                if (newPrice != -1) price = newPrice;
                line = medName + L" " + std::to_wstring(quantity) + L" " + std::to_wstring(price);
            }
            lines.push_back(line);
        }

        file.close();

        if (!found) {
            OutputTextBlock().Text(L"Medicine not found.");
            return;
        }

        // Write updated data back to file
        std::wofstream outFile(filePath);
        if (!outFile) {
            OutputTextBlock().Text(L"Error: Could not write to file.");
            return;
        }

        for (const auto& updatedLine : lines) {
            outFile << updatedLine << std::endl;
        }

        outFile.close();

        // Clear input fields
        MedicineName().Text(L"");
        Quantity().Text(L"");
        Price().Text(L"");

        // Show success message
        OutputTextBlock().Text(L"Medicine updated successfully!\nFile Path: " );
    }

    //void EditPage::myButton_Click(IInspectable const&, RoutedEventArgs const&)
    //{
    //    //myButton().Content(box_value(L"Clicked"));
    //}
}
