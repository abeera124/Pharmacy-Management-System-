#include "pch.h"
#include "ViewMedicine.xaml.h"
#include "ViewMedicine.g.cpp"
#if __has_include("ViewMedicine.g.cpp")
#endif

#include "AddPage.xaml.h"
#include "EditPage.xaml.h"
#include "DeletePage.xaml.h"
#include "MainPage.xaml.h"
#include "ViewSellRecord.xaml.h"

#include <fstream>
#include <sstream>

#include <windows.h> // For GetModuleFileNameW
#include <shlobj.h>  // For SHGetFolderPathW
//#include <winrt/impl/Windows.UI.Xaml.Media.2.h>
#include <winrt/Microsoft.UI.Xaml.Media.h>  
#include <winrt/Microsoft.UI.h>  // Ensure this is included for ColorHelper
#include <winrt/Microsoft.UI.Xaml.Media.h>
#include <winrt/Microsoft.UI.Xaml.Controls.h>
#include <winrt/Microsoft.UI.h> // Ensure this is included for ColorHelper
#include <winrt/Microsoft.UI.Xaml.h>
#include <winrt/Windows.UI.Xaml.Interop.h>

//#include <winrt/Microsoft.UI.Colors.h>      // Required for Colors
using namespace winrt::Microsoft::UI::Xaml::Media; // Add this at the top

using namespace winrt;
using namespace Microsoft::UI::Xaml;

using namespace Microsoft::UI::Xaml::Controls;


// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace winrt::Abeera::implementation
{
    int32_t ViewMedicine::MyProperty()
    {
        throw hresult_not_implemented();
    }

    void ViewMedicine::MyProperty(int32_t /* value */)
    {
        throw hresult_not_implemented();
    }

    void ViewMedicine::AddButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::AddPage>());
    }

    void ViewMedicine::EditButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::EditPage>());
    }

    void ViewMedicine::DeleteButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::DeletePage>());
    }

    void ViewMedicine::ViewSellsRecordButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::ViewSellRecord>());
    }

    void ViewMedicine::BackButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {

        auto frame = winrt::Microsoft::UI::Xaml::Controls::Frame();
        this->Content(frame);
        frame.Navigate(winrt::xaml_typename<Abeera::MainPage>());
    }



    // Function to get writable file path in the app directory
    static std::wstring GetAppDirectoryFilePath() {
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(NULL, path, MAX_PATH);

        std::wstring appPath = path;
        size_t pos = appPath.find_last_of(L"\\/");
        return appPath.substr(0, pos) + L"\\medicines.txt";
    }
    void ViewMedicine::ViewButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
        // Get the file path
        std::wstring filePath = GetAppDirectoryFilePath();

        // Open the file
        std::wifstream file(filePath);
        if (!file) {
            OutputTextBlock().Text(L"Error: Could not open file.");
            return;
        }

        // Clear the existing ListView
        MedicineListView().Items().Clear();

        // Read data and populate the ListView
        std::wstring name;
        int quantity;
        double price;

        while (file >> name >> quantity >> price)
        {
            // Trim whitespace (fixes incorrect name parsing)
            name.erase(name.find_last_not_of(L" \t") + 1);

            // Skip medicines with zero quantity
            if (quantity == 0) continue;

            // Create a TextBlock for display
            auto textBlock = winrt::Microsoft::UI::Xaml::Controls::TextBlock();
            textBlock.Text(winrt::hstring(name + L" | Qty: " + std::to_wstring(quantity) + L" | Price: $" + std::to_wstring(price)));
            textBlock.FontSize(18);

            // Set white color
            auto whiteBrush = winrt::Microsoft::UI::Xaml::Media::SolidColorBrush(
                winrt::Microsoft::UI::ColorHelper::FromArgb(255, 255, 255, 255));
            textBlock.Foreground(whiteBrush);

            // Add to ListView
            MedicineListView().Items().Append(textBlock);
        }

        file.close();
    }



   /* void ViewMedicine::myButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        myButton().Content(box_value(L"Clicked"));
    }*/
}
