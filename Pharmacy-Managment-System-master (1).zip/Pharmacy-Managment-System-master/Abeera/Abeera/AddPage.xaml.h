#pragma once

#include "AddPage.g.h"


namespace winrt::Abeera::implementation
{
    struct AddPage : AddPageT<AddPage>
    {
        AddPage()
        {
            // Xaml objects should not call InitializeComponent during construction.
            // See https://github.com/microsoft/cppwinrt/tree/master/nuget#initializecomponent
        }

        int32_t MyProperty();
        void MyProperty(int32_t value);

      

        //void myButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
        void EditButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
        void DeleteButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
        void ViewAllMedicineButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
        void ViewSellsRecordButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
        void BackButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);
        void AddButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args);


    };
}

namespace winrt::Abeera::factory_implementation
{
    struct AddPage : AddPageT<AddPage, implementation::AddPage>
    {
    };
}
