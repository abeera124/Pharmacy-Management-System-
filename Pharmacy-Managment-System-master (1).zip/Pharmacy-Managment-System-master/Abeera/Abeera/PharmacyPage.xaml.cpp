﻿#include "pch.h"
#include "PharmacyPage.xaml.h"
#include "PharmacyPage.g.cpp"
#if __has_include("PharmacyPage.g.cpp")
#endif



//using namespace Windows::Storage;

#include <fstream>
#include <sstream>

#include <windows.h> // For GetModuleFileNameW
#include <shlobj.h>  // For SHGetFolderPathW
#include <vector>
//using namespace Windows::Storage;
using namespace winrt;
using namespace Microsoft::UI::Xaml;
using namespace Microsoft::UI::Xaml::Controls;



// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.


namespace winrt::Abeera::implementation
{
    // Constructor Implementation
 
  
       

    int32_t PharmacyPage::MyProperty()
    {
        throw hresult_not_implemented();
    }

    void PharmacyPage::MyProperty(int32_t /* value */)
    {
        throw hresult_not_implemented();
    }

 

    std::vector<std::tuple<std::wstring, int, double>> billItems; // Stores (name, quantity, total price)
    double totalBillAmount = 0.0; // Stores total bill amount
    // Function to get writable file path in the app directory
   static std::wstring GetAppDirectoryFilePath() {
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(NULL, path, MAX_PATH);

        std::wstring appPath = path;
        size_t pos = appPath.find_last_of(L"\\/");
        return appPath.substr(0, pos) + L"\\medicines.txt";
    }


    void PharmacyPage::LoadMedicines()
    {
        MedicineListView().Items().Clear(); // Clear previous items

        std::wifstream file(GetAppDirectoryFilePath());
        if (!file)
        {
            OutputDebugString(L"Error: Could not open medicines.txt!\n");
            return;
        }

        std::wstring name;
        int quantity;
        double price;
        std::wstring line;

        while (std::getline(file, line))
        {
            std::wstringstream ss(line);
            ss >> name >> quantity >> price;

            std::wstring displayText = name + L" | Qty: " + std::to_wstring(quantity) + L" | Price: $" + std::to_wstring(price);
            MedicineListView().Items().Append(winrt::box_value(displayText)); // Add to ListView
        }

        file.close();
    }

    void PharmacyPage::LoadMedicinesIntoListView()
    {
        MedicineListView().Items().Clear(); // Clear previous items

        std::wifstream file(GetAppDirectoryFilePath());
        if (!file) {
            OutputDebugString(L"Error: Could not open medicines.txt!\n");
            return;
        }

        std::wstring name;
        int quantity;
        double price;
        std::wstring line;

        while (std::getline(file, line)) {
            std::wstringstream ss(line);
            ss >> name >> quantity >> price;

            // ✅ Skip medicines with zero quantity
            if (quantity == 0) {
                continue;
            }

            std::wstring displayText = name + L" | Qty: " + std::to_wstring(quantity) + L" | $" + std::to_wstring(price);
            MedicineListView().Items().Append(winrt::box_value(winrt::hstring(displayText)));
        }

        file.close();
    }

    void PharmacyPage::AddToBillButton_Click(
        winrt::Windows::Foundation::IInspectable const&,
        winrt::Microsoft::UI::Xaml::RoutedEventArgs const&)
    {
        std::wstring medicineName = MedicineNameTextBox().Text().c_str();
        std::wstring quantityStr = QuantityTextBox().Text().c_str();

        if (medicineName.empty() || quantityStr.empty()) {
            OutputTextBlock().Text(L"Please enter medicine name and quantity.");
            return;
        }

        int purchaseQuantity = std::stoi(quantityStr);
        if (purchaseQuantity <= 0) {
            OutputTextBlock().Text(L"Invalid quantity!");
            return;
        }

        std::wifstream file(GetAppDirectoryFilePath());
        if (!file) {
            OutputTextBlock().Text(L"Error: Unable to open medicine file!");
            return;
        }

        std::wstring name;
        int stockQuantity;
        double price;
        bool medicineFound = false;
        int availableQuantity = 0;
        std::vector<std::wstring> updatedMedicines;  // To store updated medicines for saving

        while (file >> name >> stockQuantity >> price) {
            if (name == medicineName) {
                medicineFound = true;
                availableQuantity = stockQuantity;

                // ✅ Deduct stock
                if (availableQuantity < purchaseQuantity) {
                    OutputTextBlock().Text(L"Not enough stock available!");
                    file.close();
                    return;
                }
                stockQuantity -= purchaseQuantity; // Reduce stock after adding to bill

                // Add the updated medicine to the list
                updatedMedicines.push_back(name + L" " + std::to_wstring(stockQuantity) + L" " + std::to_wstring(price));

                // ✅ Check if the medicine is already in the bill
                bool foundInBill = false;
                for (auto& item : billItems) {
                    if (std::get<0>(item) == medicineName) {
                        // Medicine is already in the bill, increase quantity and price
                        std::get<1>(item) += purchaseQuantity;  // Increase quantity
                        std::get<2>(item) += purchaseQuantity * price;  // Increase total price
                        foundInBill = true;
                        break;
                    }
                }

                if (!foundInBill) {
                    // Medicine not in the bill, add it
                    billItems.push_back({ medicineName, purchaseQuantity, purchaseQuantity * price });
                }

                // ✅ Update total bill amount
                totalBillAmount += purchaseQuantity * price;
            }
            else {
                // Add other medicines to updated list without any changes
                updatedMedicines.push_back(name + L" " + std::to_wstring(stockQuantity) + L" " + std::to_wstring(price));
            }
        }
        file.close();

        if (!medicineFound) {
            OutputTextBlock().Text(L"Medicine not found!");
            return;
        }

        // ✅ Save updated stock
        std::wofstream outFile(GetAppDirectoryFilePath());
        for (const auto& med : updatedMedicines) {
            outFile << med << L"\n";
        }
        outFile.close();

        // ✅ Refresh the bill display
        std::wstringstream billText;
        billText << L"Bill Summary:\n";
        for (const auto& item : billItems) {
            billText << std::get<0>(item) << L" | Qty: " << std::get<1>(item) << L" | $" << std::get<2>(item) << L"\n";
        }

        billText << L"--------------------\n";
        billText << L"Total Bill: $" << totalBillAmount;

        BillTextBlock().Text(winrt::hstring(billText.str()));

        OutputTextBlock().Text(L"Medicine added to bill!");
    }






    void PharmacyPage::BuyButton_Click(
        winrt::Windows::Foundation::IInspectable const&,
        winrt::Microsoft::UI::Xaml::RoutedEventArgs const&)
    {
        if (billItems.empty()) {
            OutputTextBlock().Text(L"No items in the bill!");
            return;
        }

        std::wifstream file(GetAppDirectoryFilePath());
        if (!file) {
            OutputTextBlock().Text(L"Error: Unable to open medicine file!");
            return;
        }

        std::vector<std::wstring> updatedMedicines;
        std::wstring name;
        int stockQuantity;
        double price;

        while (file >> name >> stockQuantity >> price) {
            for (auto& item : billItems) {
                if (std::get<0>(item) == name) {
                    stockQuantity -= std::get<1>(item);  // Deduct stock based on bill
                }
            }

            // ✅ Only keep medicines with stock left
            if (stockQuantity > 0) {
                updatedMedicines.push_back(name + L" " + std::to_wstring(stockQuantity) + L" " + std::to_wstring(price));
            }
        }
        file.close();

        // ✅ Save updated stock
        std::wofstream outFile(GetAppDirectoryFilePath());
        for (const auto& med : updatedMedicines) {
            outFile << med << L"\n";
        }
        outFile.close();

        // ✅ Save bill to file
        std::wofstream billFile(L"bill.txt", std::ios::app);
        if (billFile) {
            std::wstringstream billText;
            billText << L"Final Bill:\n";
            for (const auto& item : billItems) {
                billText << std::get<0>(item) << L" | Qty: " << std::get<1>(item) << L" | $" << std::get<2>(item) << L"\n";
            }
            billText << L"Total Amount: $" << totalBillAmount << L"\n";
            billText << L"--------------------\n";
            billFile << billText.str();
            billFile.close();
        }

        // ✅ Reset bill list
        billItems.clear();
        totalBillAmount = 0.0;

        // ✅ Update UI
        LoadMedicinesIntoListView();
        BillTextBlock().Text(L"");
        OutputTextBlock().Text(L"Purchase successful!");
    }





  
  

    //void PharmacyPage::myButton_Click(IInspectable const&, RoutedEventArgs const&)
    //{
    //    //myButton().Content(box_value(L"Clicked"));
    //}
}
