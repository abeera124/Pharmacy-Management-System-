#include "pch.h"
#include "AdminPage.xaml.h"
#include "AdminPage.g.cpp"
#if __has_include("AdminPage.g.cpp")
#endif

using namespace winrt;
using namespace Microsoft::UI::Xaml;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace winrt::Abeera::implementation
{
    int32_t AdminPage::MyProperty()
    {
        throw hresult_not_implemented();
    }

    void AdminPage::MyProperty(int32_t /* value */)
    {
        throw hresult_not_implemented();
    }

    void AdminPage::AddButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
    }

    void AdminPage::EditButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
    }

    void AdminPage::DeleteButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
    }

    void AdminPage::ViewAllButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
    }

    void AdminPage::ViewBillsButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
    }

    void AdminPage::BackButton_Click(IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const& args)
    {
    }

  /*  void AdminPage::myButton_Click(IInspectable const&, RoutedEventArgs const&)
    {
        myButton().Content(box_value(L"Clicked"));
    }*/
}
